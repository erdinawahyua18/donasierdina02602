<!--
Template Name: Charity Hope
Title: charity website template free download bootstrap Charity Hope
Description: charity website template with bootstrap framework for free download best suited for ngos charities.
Keyword: charity website template, bootstrap charity template free, charity website templates bootstrap, donation website template free, charity website templates bootstrap free download
Author: Bootstrap Website Templates
Author URI: https://bootstrapwebtemplates.com/
Template URI: https://bootstrapwebtemplates.com/free-download-bootstrap-charity-website-template
Tags: charity, charity hub, donate, donations, foundation, fundraising, ngo, non profit, non-profit, nonprofit, organization, social, volunteer, welfare, Causes
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE HTML>
<html class="no-js" lang="de">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="robots" content="index,follow">

<title>Charity Hope</title>

<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="css/animate.css" rel="stylesheet">
<link href="css/bootsnav.css" rel="stylesheet">
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" href="css/swipebox.css">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'> 
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">  
</head>
<body>
<div class="topbar">
<div class="container">
<div class="row"> 
</div>
</div>
</div>
</div>
<nav class="navbar navbar-default navbar-sticky bootsnav">
<div class="container">
<div class="row"> 
<div class="attr-nav">
<a class="sponsor-button" href="suggest.php">suggest</a>
<a class="donation" href="donate.php">donate now</a>
</div>           
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
<i class="fa fa-bars"></i>
</button>
<a class="navbar-brand logo" href="index.php"><img src="images/logo.png" class="img-responsive" /></a>
</div>
<div class="collapse navbar-collapse" id="navbar-menu">
<ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
<li><a href="index.php">Home</a></li>
<li><a href="about-us.php">About Us</a></li>
<li><a href="activities.php">Activities</a></li>
<li><a href="projects.php">Projects</a></li>
<li><a href="gallery.php">Gallery</a></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</div>
</div>
</div>
</nav>

<section id="inner-banner">
<div class="overlay">
<div class="container">
<div class="row"> 
<div class="col-sm-6"><h1>GALLERY</h1></div>
<div class="col-sm-6">
  <h6 class="breadcrumb"><a href="index.php">Home</a> / Gallery</h6></div>
</div>
</div>
</div>
</section>

<section id="gallery-sec" style="margin-top:40px;">
<div class="container">
<div class="row text-center">
<ul class="clearfix">
<li>
<a href="images/gallery1.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery1.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div></a>
</li>
<li>
<a href="images/gallery2.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery2.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery3.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery3.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery4.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery4.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery5.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery5.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery6.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery6.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery7.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery7.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery8.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery8.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery1.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery1.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div></a>
</li>
<li>
<a href="images/gallery2.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery2.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery3.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery3.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery4.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery4.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery5.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery5.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery6.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery6.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery7.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery7.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
<li>
<a href="images/gallery8.jpg" class="swipebox" title="My Caption">
<div class="image"><img src="images/gallery8.jpg">
<div class="overlay"><i class="fa fa-search-plus"></i></div>
</div>
</a>
</li>
</ul>
</div>
</div>
</section>


<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/bootsnav.js"></script>
<script src="js/banner.js"></script>
<script src="js/jquery.swipebox.js"></script>
<script type="text/javascript">
	$( document ).ready(function() {

			/* Basic Gallery */
			$( '.swipebox' ).swipebox();
			
			/* Video */
			$( '.swipebox-video' ).swipebox();

			/* Dynamic Gallery */
			$( '#gallery' ).click( function( e ) {
				e.preventDefault();
				$.swipebox( [
					{ href : 'http://swipebox.csag.co/mages/image-1.jpg', title : 'My Caption' },
					{ href : 'http://swipebox.csag.co/images/image-2.jpg', title : 'My Second Caption' }
				] );
			} );

      });
	</script>  
    <script src="js/script.js"></script>
</body>
</html>
