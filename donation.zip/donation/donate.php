<!--
Template Name: Charity Hope
Title: charity website template free download bootstrap Charity Hope
Description: charity website template with bootstrap framework for free download best suited for ngos charities.
Keyword: charity website template, bootstrap charity template free, charity website templates bootstrap, donation website template free, charity website templates bootstrap free download
Author: Bootstrap Website Templates
Author URI: https://bootstrapwebtemplates.com/
Template URI: https://bootstrapwebtemplates.com/free-download-bootstrap-charity-website-template
Tags: charity, charity hub, donate, donations, foundation, fundraising, ngo, non profit, non-profit, nonprofit, organization, social, volunteer, welfare, Causes
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php
require 'config/function.php';
?>
<?php
if (isset($_POST["submitbar"])) {
  if (tambahbar($_POST) > 0) {
    echo "<script language='javascript'>swal('Good...', 'Data Berhasil di Input!', 'success');</script>";
  }else {
      echo "";
  }
}
elseif (isset($_POST["updatebar"])) {
  if (updatebar($_POST) > 0) {
    echo "<script language='javascript'>swal('Good...', 'Data Berhasil di Ubah!', 'success');</script>";
  }else {
    echo "<script language='javascript'>swal('Info...', 'Tidak Ada Data Yang Di Ubah!', 'info');</script>";
  }
}

?>
<!DOCTYPE HTML>
<html class="no-js" lang="de">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="robots" content="index,follow">

<title>Charity Hope</title>

<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="css/animate.css" rel="stylesheet">
<link href="css/bootsnav.css" rel="stylesheet">
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">

    	<link rel="stylesheet" type="text/css" href="css/sweetalert2.css">
	<link href="css/sweetalert.css" rel="stylesheet" type="text/css">
   	<script type="text/javascript" src="js/sweetalert2.min.js"></script>
    <script src="js/sweetalert.min.js"></script>                
  	<script src="js/sweetalert-dev.js"></script> 

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'> 
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">  
</head>
<body>
<div class="topbar">
<div class="container">
<div class="row"> 

<div class="header-social">
<a class="facebook" href="#" title="facebook" target="_blank" rel="nofollow"><i class="fa fa-facebook"></i>  </a>
<a class="twitter" href="#" title="twitter" target="_blank" rel="nofollow"><i class="fa fa-twitter"></i>  </a>
</div>
</div>
</div>
</div>
<nav class="navbar navbar-default navbar-sticky bootsnav">
<div class="container">
<div class="row"> 
<div class="attr-nav">
<a class="sponsor-button" href="suggest.php">suggest</a>
<a class="donation" href="donate.php">donate</a>
</div>           
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
<i class="fa fa-bars"></i>
</button>
<a class="navbar-brand logo" href="index.php"><img src="images/logo.png" class="img-responsive" /></a>
</div>
<div class="collapse navbar-collapse" id="navbar-menu">
<ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
<li><a href="index.php">Home</a></li>
<li><a href="about-us.php">About Us</a></li>
<li><a href="activities.php">Activities</a></li>
<li><a href="projects.php">Projects</a></li>
<li><a href="gallery.php">Gallery</a></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</div>
</div>
</div>
</nav>

<section id="inner-banner">
<div class="overlay">
<div class="container">
<div class="row"> 
<div class="col-sm-6"><h1>DONATE</h1></div>
<div class="col-sm-6">
  <h6 class="breadcrumb"><a href="index.php">Home</a> / Donate</h6></div>
</div>
</div>
</div>
</section>

<section id="about-sec">
<div class="container">
<div class="row text-center">
<h2 style="margin-top:0;">I WISH TO MAKE A DONATION<br>
WE NEED YOUR HELP TO HELP OTHERS</h2>
<div class="con-form clearfix">
<div class="col-md-6">
<form action="" method="post">
<input type="text" name="nama" value="" size="40" class="" aria-required="true" aria-invalid="false" placeholder="Nama Depan Lengkap*">
</div>
<div class="col-md-6">
<input type="text" name="telepon" value="" size="40" class="" aria-invalid="false" placeholder="Nomor Telepon*">
</div>
<div class="col-md-6">
<input type="email" name="email" value="" size="40" class="" aria-invalid="false" placeholder="Email ID*">
</div>
<div class="col-md-6">
<input type="text" name="alamat" value="" size="40" class="" aria-required="true" aria-invalid="false" placeholder="Alamat*">
</div>
<div class="col-md-6">
<input type="text" name="jumlahdonasi" value="" size="40" class="" aria-required="true" aria-invalid="false" placeholder="Jumlah*">
</div>
<div class="col-md-6">
<input type="text" name="jenisdonasi" value="" size="40" class="" aria-required="true" aria-invalid="false" placeholder="jenis donasi ex: Uang, barang, sembako dll">
</div>
<div class="col-md-12">
<textarea name="pesan" cols="40" rows="5" class="" id="message" aria-invalid="false" placeholder="Pesan"></textarea>
</div>
<div class="col-xs-12 submit-button">
<input type="submit" name="submitbar" value="Donate" class="btn2" id="sub" style="border:none; margin: 20px 0 0 0">
</div>
</div>
</div>
</div>
</form>
</section>


<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/bootsnav.js"></script>
<script src="js/banner.js"></script> 
<script src="js/script.js"></script> 
</body>
</html>
