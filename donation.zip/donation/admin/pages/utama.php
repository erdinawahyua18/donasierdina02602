<br>
<?php
require 'config/function.php';
$username = $_SESSION['username'];
$adm = query("SELECT * FROM admin WHERE username='$username'");
?>
<?php foreach($adm as $row) : ?>
<?php
function konversistatus($info){
$status = $info;
$flags = array (
'0'=>'Pengguna',
'1'=>'Super Admin'
);
echo $flags[$status];
}?>
<?php endforeach; ?>

<section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-teal">
            <div class="inner">
              <h3><?php
              $kat = mysqli_query($conn,"SELECT * FROM donasi");
              $ok = mysqli_num_rows($kat);
              echo "$ok";
              ?></h3>
              <p>Donasi</p>
            </div>
            <div class="icon">
              <i class="ion ion-pricetags"></i>
            </div>
            <a href="main.php?pages=kategori" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-6 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-maroon">
            <div class="inner">
              <h3><?php

                function rupiah($angka){
                  $hasiljadi = "Rp. ".number_format($angka,2,',','.');
                  return $hasiljadi;
                }

              $cus = mysqli_query($conn,"SELECT sum(jumlahdonasi) as jumlah from donasi");
              $ok = mysqli_fetch_array($cus);

              $rup = $ok['jumlah'];

              echo rupiah($rup);;
              ?></h3>

              <p>Jumlah Donasi</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="main.php?pages=customer" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->

        <!-- ./col -->
        <!-- ./col -->
      </div>
      <!-- /.row -->  








    </section>